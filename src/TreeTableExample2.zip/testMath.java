
public class testMath {
	
	
	public static void main(String args[]) {
		System.out.println("tst");
		int i = 9%4;
		System.out.println(i);
	}

}
